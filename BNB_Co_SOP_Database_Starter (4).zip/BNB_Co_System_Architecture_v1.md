# BNB Co. S&OP — Logical Systems Architecture v1.0

**Status:** Proposed prototype architecture, 17 October 2026. Fictional enterprise and synthetic data.

## Business systems (user-confirmed)

1. SAP ERP owns masters and transactional inventory.
2. BNB in-house POS bills distributors at local warehouses and transmits sales to SAP at noon and midnight.
3. Blue Yonder Inventory Optimization owns inventory planning and recommendations; SAP retains posted stock balances.
4. o9 Solutions produces demand forecasts and demand plans.
5. Llamasoft is the network design/optimization tool in the fictional business landscape.
6. Blue Yonder Distribution Planning produces distribution and replenishment plans.
7. Each application uses its own native schema; data from all six flows to a common enterprise data lake.

## Logical architecture

```mermaid
flowchart TB
  POS[BNB Local-Warehouse POS] -->|12:00 and 00:00 scheduled sales feed| SAP[SAP ERP]
  SAP -->|Masters / inventory / transactions| RAW[(Data Lake: Source / Raw Zone)]
  POS -.->|Direct-to-lake feed not yet confirmed| RAW
  O9[o9 Demand Planning] --> RAW
  BYIO[Blue Yonder Inventory Optimization] --> RAW
  LL[LLamasoft Network Optimization] --> RAW
  BYDP[Blue Yonder Distribution Planning] --> RAW
  RAW --> QUALITY[Schema mapping / data quality / lineage / harmonization]
  QUALITY --> CURATED[(Curated S&OP Planning Data)]
  CURATED --> TOOLS[Read-only Planning APIs + Validated Calculation Engines]
  TOOLS --> AI[OpenAI S&OP Orchestrator and Specialist Agents]
  AI --> REVIEW[Planner Dashboard and Human Approval]
  REVIEW -.->|Future controlled write-back subject to approval| SAP
  REVIEW -.->|Future controlled write-back subject to approval| O9
  REVIEW -.->|Future controlled write-back subject to approval| BYIO
  REVIEW -.->|Future controlled write-back subject to approval| BYDP
```

**Important:** POS to data lake direct feed is not confirmed. The base design assumes POS → SAP → data lake. Feedback into planning applications is not implemented and requires a separate decision.

## Data zones
- **Raw/source:** Records received from each vendor/system, retained in their source identity and ingestion timestamps.
- **Standardized:** SKU/location crosswalks, consistent time/calendar, canonical units, row validation, data freshness.
- **Curated:** Subject-level sales, forecasts, inventory, orders, production, capacity, network, scenarios, and approved plans.
- **Serving:** SQL views / constrained service APIs that read curated datasets on behalf of the agents.

## Prototype mapping (NOT native vendor export schemas)
- SAP ERP stand-ins: `item_master`, `supplier_master`, `location_master`, `item_location_master`, `inventory_movements`, `inventory_opening`, `inventory_snapshot`, `production_orders`, etc.
- POS stand-in: `sales_history`; the CSV represents sales delivered to ERP, not the full native POS transaction model.
- o9 stand-ins: `forecast_history`, `demand_plan`.
- LLamasoft stand-in: `item_warehouse_routes` and `network_lane_master` where applicable, but these are route/reference data rather than solver outputs.
- Blue Yonder Distribution Planning: `scheduled_receipts` is only a partial stand-in.
- Blue Yonder Inventory Optimization: no genuine recommendation output or source-specific schema in the current files; `inventory_policy` and recommendation outputs should be added.

## What was built
- A SQLite local relational database populated from 23 CSVs (not a data lake implementation).
- `dataset_catalog` records the proposed lineage of each table.
- `system_registry` describes the fictional applications.
- `v_pos_sales`, `v_sap_stock`, `v_o9_demand_plan`, `v_sop_inventory_by_sku_location`, and `v_sop_demand_month` are convenience views.
- A machine-readable validation JSON and reproducible database import script accompany the database.

## Boundaries and caveats
- Synthetic business data; no actual SAP, o9, Blue Yonder, LLamasoft, or POS connection.
- Source ownership is a modeling proposal, not verified schema documentation.
- No fully reconciled multi-echelon upstream inventory; batch-level warehouse balances are available.
- No production-grade authorization, lake orchestration, CDC, idempotent incremental loads, failure handling, or vendor write-backs.
- The scenario/plan outputs are illustrative, not mathematically optimized.

## Essential architecture decisions to confirm
1. What is the cloud/data platform: Azure, AWS, GCP, on-premises or undetermined? (Prototype can remain SQLite.)
2. Do the planning apps receive updates from SAP, lake, or each other? Is the data lake ingestion-only, or the canonical interchange hub?
3. How often are each planning app's outputs loaded into the lake: batch daily, at every plan publish, or event-driven?
4. Are AI outputs recommendation-only or allowed to write approved scenarios back to source apps?
5. What entities/versions are system-of-record for overrides and approved demand/supply/inventory plans?

## Proposed next build milestone
First build a source data freshness dashboard and SKU-location demand/inventory query with correct business dates and source-attribution, then add a simple read-only OpenAI agent with function tools. Introduce optimization and controlled write-backs only after validation.
