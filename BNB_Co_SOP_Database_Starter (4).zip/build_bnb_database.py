import csv, sqlite3, pathlib, json, zipfile, time, os
src=pathlib.Path('/mnt/data/bnb_sop_dataset')
out=pathlib.Path('/mnt/data/BNB_Co_SOP_Prototype.sqlite')
if out.exists():out.unlink()
conn=sqlite3.connect(out)
conn.execute('PRAGMA journal_mode=OFF')
conn.execute('PRAGMA synchronous=OFF')
conn.execute('PRAGMA cache_size=-100000')
conn.execute('CREATE TABLE dataset_catalog(table_name TEXT PRIMARY KEY, source_system TEXT NOT NULL, source_dataset TEXT, ingestion_method TEXT, refresh_rule TEXT, data_layer TEXT, notes TEXT)')
map_source={
 'item_master':'SAP ERP','location_master':'SAP ERP','supplier_master':'SAP ERP','item_location_master':'SAP ERP','network_lane_master':'SAP ERP (reference network)','factory_capacity':'SAP ERP','calendar_master':'SAP ERP','cost_parameters':'SAP ERP',
 'sales_history':'BNB POS via SAP ERP','customer_orders':'BNB POS via SAP ERP',
 'inventory_movements':'SAP ERP','inventory_snapshot':'SAP ERP','inventory_opening':'SAP ERP','production_orders':'SAP ERP','transfer_orders':'SAP ERP','wastage_history':'SAP ERP',
 'forecast_history':'o9 Solutions','demand_plan':'o9 Solutions',
 'approved_supply_plan':'SAP ERP (approved production plan)','scheduled_receipts':'SAP ERP / Blue Yonder Distribution Planning',
 'item_warehouse_routes':'LLamasoft network design (simulated)','scenario_parameters':'LLamasoft / S&OP what-if (simulated)',
}
# Caution: not all CSVs have verifiable origin. Labels here indicate intended logical owners, not actual extracted system schemas.
def source_for(tab):
 if tab in map_source: return map_source[tab]
 return 'Reference / synthetic generator'
results={}
for file in sorted(src.glob('*.csv')):
 tab=file.stem
 if tab=='data_dictionary':continue
 with file.open(newline='',encoding='utf-8-sig') as h:
  reader=csv.DictReader(h); cols=reader.fieldnames
  types={c:'TEXT' for c in cols}
  sample=[]
  for i,row in enumerate(reader):
   sample.append(row)
   if i>=499: break
  for c in cols:
   vals=[row[c] for row in sample if row[c] not in ('',None)]
   if not vals: continue
   if c.endswith('_id') or c.endswith('_date') or c in ('date','month','week_start','as_of_date','snapshot_date','production_date','expiry_date','shipped_date','receipt_date','forecast_created_month','target_month','target_week','order_date','requested_delivery_date','expected_receipt_date') or c in ('status','source','mode') or c.endswith('_version'):
    continue
   try:
    if all(str(v).lstrip('-').isdigit() for v in vals): types[c]='INTEGER'
    elif all(float(v) or True for v in vals): types[c]='REAL'
   except (ValueError,TypeError):pass
  ddl=', '.join('"%s" %s'%(c,types[c]) for c in cols)
  conn.execute(f'CREATE TABLE "{tab}" ({ddl})')
  sql=f'INSERT INTO "{tab}" VALUES ({",".join("?" for c in cols)})'
  batch=[];n=0
  def convert(row):
   out=[]
   for c in cols:
    v=row[c]
    if v=='':v=None
    elif types[c]=='INTEGER':v=int(v)
    elif types[c]=='REAL':v=float(v)
    out.append(v)
   return out
  for row in sample:
   batch.append(convert(row));n+=1
  for row in reader:
   batch.append(convert(row));n+=1
   if len(batch)>=5000:
    conn.executemany(sql,batch);batch.clear()
  if batch: conn.executemany(sql,batch)
  refresh='Twice daily at 00:00 and 12:00 local time (via SAP)' if tab in ('sales_history','customer_orders') else 'Synthetic batch snapshot; production frequency TBD'
  conn.execute('INSERT INTO dataset_catalog VALUES (?,?,?,?,?,?,?)',(tab,source_for(tab),file.name,'CSV batch import',refresh,'bronze-compatible raw relational tables','Source attribution is an architectural mapping, not an actual vendor schema or connector.'))
  results[tab]=n
# Create compatibility views showing source groupings; keep original raw table names.
conn.execute('CREATE VIEW v_pos_sales AS SELECT * FROM sales_history')
conn.execute('CREATE VIEW v_sap_stock AS SELECT * FROM inventory_opening')
conn.execute('CREATE VIEW v_o9_demand_plan AS SELECT * FROM demand_plan')
conn.execute('CREATE VIEW v_sop_inventory_by_sku_location AS SELECT sku_id,location_id,SUM(on_hand_units) AS on_hand_units,SUM(usable_units) AS usable_units FROM inventory_opening GROUP BY sku_id,location_id')
conn.execute('CREATE VIEW v_sop_demand_month AS SELECT sku_id,warehouse_id,target_month,SUM(forecast_units) AS demand_units FROM demand_plan WHERE scenario_id="BASE" GROUP BY sku_id,warehouse_id,target_month')
for table,col in [('sales_history','date'),('sales_history','sku_id'),('demand_history','date'),('demand_history','sku_id'),('inventory_opening','sku_id'),('inventory_movements','batch_id'),('customer_orders','order_id'),('forecast_history','target_month'),('demand_plan','target_month'),('item_location_master','sku_id'),('item_warehouse_routes','sku_id')]:
 conn.execute(f'CREATE INDEX "idx_{table}_{col}" ON "{table}"("{col}")')
conn.execute('CREATE TABLE system_registry(system_name TEXT PRIMARY KEY, role TEXT, system_type TEXT, integration_path TEXT, caveat TEXT)')
registry=[
 ('SAP ERP','Master data, posted inventory, production and ERP transactions','ERP','SAP → data lake','Simulated from CSVs; not SAP schema'),
 ('BNB POS','Distributor billing and local warehouse sales','In-house POS','POS → SAP at noon/midnight → lake','No original POS transaction identifier in current sales_history'),
 ('Blue Yonder Inventory Optimization','Inventory optimization policies, targets and recommendations','Planning','BY IO → data lake','Proposed system; no native optimization output file yet'),
 ('o9 Solutions','Demand forecasting and demand planning','Planning','o9 → data lake','Demand/forecast CSVs are stand-in exports'),
 ('LLamasoft','Network design and optimization','Network planning','LLamasoft → data lake','Route master is a stand-in export, not solution output'),
 ('Blue Yonder Distribution Planning','Distribution and replenishment planning','Planning','BY DP → data lake','Scheduled receipts are stand-in, not complete BY plans'),
 ('BNB Enterprise Data Lake','Central multi-schema storage and ingestion','Data platform','Raw → standardized → curated','SQLite file is a local relational prototype, not an actual lake'),
 ('OpenAI S&OP Agent Layer','Query, explanation, scenario orchestration','AI application','Agent tools → curated database (read-only)','Not yet implemented'),
]
conn.executemany('INSERT INTO system_registry VALUES (?,?,?,?,?)',registry)
conn.commit()
checks={
 'item_master_rows':conn.execute('SELECT COUNT(*) FROM item_master').fetchone()[0],
 'supplier_master_rows':conn.execute('SELECT COUNT(*) FROM supplier_master').fetchone()[0],
 'location_rows':conn.execute('SELECT COUNT(*) FROM location_master').fetchone()[0],
 'inventory_opening_rows':conn.execute('SELECT COUNT(*) FROM inventory_opening').fetchone()[0],
 'sales_history_rows':conn.execute('SELECT COUNT(*) FROM sales_history').fetchone()[0],
 'sqlite_integrity':conn.execute('PRAGMA integrity_check').fetchone()[0],
 'tables_imported':len(results),
 'row_count_by_table':results,
 'missing_items_in_sales':conn.execute('SELECT COUNT(*) FROM sales_history s LEFT JOIN item_master i ON s.sku_id=i.sku_id WHERE i.sku_id IS NULL').fetchone()[0]
}
conn.close()
path=pathlib.Path('/mnt/data/BNB_Co_Database_Validation.json');path.write_text(json.dumps(checks,indent=2))
with zipfile.ZipFile('/mnt/data/BNB_Co_SOP_Database_Starter.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 z.write(out,out.name);z.write(path,path.name);z.write('/mnt/data/build_bnb_database.py','build_bnb_database.py')
print(json.dumps({k:v for k,v in checks.items() if k!='row_count_by_table'},indent=2));print('DB bytes',out.stat().st_size)
